package com.psl.sixforce.util;

import weka.classifiers.functions.SMO;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.instance.RemovePercentage;

public class MLRunner {
	
	public static String SVMpredict(SMO svm,Instance instance) throws Exception{
		
		double actualClass = instance.classValue();
		String actual = instance.classAttribute().value((int) actualClass);
		Instance tInstance=instance;
		double predNB = svm.classifyInstance(tInstance);
		String predString = instance.classAttribute().value((int) predNB);
		System.out.println(actual + ", " + predString);
		
		return actual + ", " + predString;
		
		
	}
	public static  SMO svmTrain(SMO svm,Instances testDataSet) throws Exception{
		svm.buildClassifier(testDataSet);
		return svm;
		
	}
	
	public  static SMO createSVM(String... parameters) throws Exception{
		
		SMO svm=new SMO();
		svm.setOptions(parameters);
		return svm;
		
		
	}
	
public static void main(String s[]) throws Exception {
		
		DataSource source = new DataSource("trainingSet/pharynx_shruti.arff");
		Instances dataSet = source.getDataSet();
		dataSet.setClassIndex(dataSet.numAttributes() - 1);
		
		
		  
		  RemovePercentage rmvp1 = new RemovePercentage();
			rmvp1.setInputFormat(dataSet);
			rmvp1.setPercentage(99);
			rmvp1.setInvertSelection(true);
			Instances trainDataSet = Filter.useFilter(dataSet, rmvp1);

			RemovePercentage rmvp2 = new RemovePercentage();
			rmvp2.setInputFormat(dataSet);
			rmvp2.setPercentage(99);
			rmvp2.setInvertSelection(false);
			Instances testDataSet = Filter.useFilter(dataSet, rmvp2);
		  
		  
		 
		
		
		
		
		
		int numClasses = dataSet.numClasses();
		for (int i = 0; i < numClasses; i++) {
			String classValue = dataSet.classAttribute().value(i);
			System.out.println("Class Value " + i + " is " + classValue);
		}
		
		
		SMO svm=createSVM();
		SMO trainedSvm=svmTrain(svm,trainDataSet);
		
		System.out.println(SVMpredict(trainedSvm,testDataSet.firstInstance()));
		
		
		
		

}
}